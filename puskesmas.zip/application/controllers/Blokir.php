<?php
class Blokir extends CI_Controller{
    
    
    //halo
    function index(){
        $this->load->view('auth/blokir_akses');
    }
}