<div class="content-wrapper">
    <section class="content">
        <div class="box box-warning box-solid">
            <div class="box-header with-border">
                <h3 class="box-title">Cek Data BPJS</h3>
            </div>
            <iframe frameborder="yes" width="100%" height="1300px" name="frame1" scrolling="auto" src="https://daftar.bpjs-kesehatan.go.id/bpjs-checking/" style="border: 1px solid;"></iframe>
        </div>
    </section>
</div>
<!-- halo -->
        <footer class="site-footer">
          <div class="text-center">
            <p>
              &copy; Copyrights <strong>PT DILEM WILIS 2019</strong>. All Rights Reserved
            </p>
            <div class="credits">             
            </div>
          </div>
        </footer>