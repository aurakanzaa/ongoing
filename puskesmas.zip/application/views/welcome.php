<div class="content-wrapper">
    <section class="content">
       <!-- <div class="btn btn-lg btn-warning"> -->
       	<img src="<?php echo base_url() ?>/assets/foto_profil/bg.jpeg" width="100%">
       <!-- </div> -->
        
    </section>
</div>
