<div class="content-wrapper">
    <section class="content">
       <div class="btn btn-lg btn-warning"><span class="glyphicon glyphicon-check"></span>Anda Telah Memasuki Halaman Dashboard Sistem Pelayanan Puskesmas</div>
        
    </section>
</div>
